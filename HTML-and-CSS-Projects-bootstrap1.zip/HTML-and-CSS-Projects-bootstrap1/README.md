# HTML-and-CSS-Projects
Here is my movie theatre website. To create it,I used bootstrap4.
It has many Bootstrap components,including but not limited to:
-navbar,jumbotron,form,cards,dropdowns.
